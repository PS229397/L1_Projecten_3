﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace L1_Project_3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        //Menu bar functionality
        private void MenuPartijen_Click(object sender, RoutedEventArgs e)
        {
            //als een item wordt geselecteerd wordt het ge-highlight
            MenuPartijen.Background = Brushes.White;
            MenuPartijen.Foreground = Brushes.Black;
            MenuThemas.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuThemas.Foreground = Brushes.Black;
            MenuPunten.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuPunten.Foreground = Brushes.Black;
            MenuVerkiezingsSoorten.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuVerkiezingsSoorten.Foreground = Brushes.Black;
            MenuVerkiezingen.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuVerkiezingen.Foreground = Brushes.Black;

            //zet de benodigde elementen op visible en alles wat niet nodig is op hidden
            DgPartijen.Visibility = Visibility.Visible;
            DgThemas.Visibility = Visibility.Hidden;
            DgPunten.Visibility = Visibility.Hidden;
            DgVerkiezingsSoorten.Visibility = Visibility.Hidden;
            DgVerkiezingen.Visibility = Visibility.Hidden;

            BtnAddPartijen.Visibility = Visibility.Visible;
            BtnRemovePartijen.Visibility = Visibility.Visible;
            BtnEditPartijen.Visibility = Visibility.Visible;

            BtnAddThemas.Visibility = Visibility.Hidden;
            BtnRemoveThemas.Visibility = Visibility.Hidden;
            BtnEditThemas.Visibility = Visibility.Hidden;

            BtnAddPunten.Visibility = Visibility.Hidden;
            BtnRemovePunten.Visibility = Visibility.Hidden;
            BtnEditPunten.Visibility = Visibility.Hidden;

            BtnAddVerkiezingsSoorten.Visibility = Visibility.Hidden;
            BtnRemoveVerkiezingsSoorten.Visibility = Visibility.Hidden;
            BtnEditVerkiezingsSoorten.Visibility = Visibility.Hidden;

            BtnAddVerkiezingen.Visibility = Visibility.Hidden;
            BtnRemoveVerkiezingen.Visibility = Visibility.Hidden;
            BtnEditVerkiezingen.Visibility = Visibility.Hidden;
            BtnVerkiesbaar.Visibility = Visibility.Hidden;
        }

        private void MenuThemas_Click(object sender, RoutedEventArgs e)
        {
            MenuPartijen.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuPartijen.Foreground = Brushes.Black;
            MenuThemas.Background = Brushes.White;
            MenuThemas.Foreground = Brushes.Black;
            MenuPunten.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuPunten.Foreground = Brushes.Black;
            MenuVerkiezingsSoorten.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuVerkiezingsSoorten.Foreground = Brushes.Black;
            MenuVerkiezingen.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuVerkiezingen.Foreground = Brushes.Black;

            DgPartijen.Visibility = Visibility.Hidden;
            DgThemas.Visibility = Visibility.Visible;
            DgPunten.Visibility = Visibility.Hidden;
            DgVerkiezingsSoorten.Visibility = Visibility.Hidden;
            DgVerkiezingen.Visibility = Visibility.Hidden;

            BtnAddPartijen.Visibility = Visibility.Hidden;
            BtnRemovePartijen.Visibility = Visibility.Hidden;
            BtnEditPartijen.Visibility = Visibility.Hidden;

            BtnAddThemas.Visibility = Visibility.Visible;
            BtnRemoveThemas.Visibility = Visibility.Visible;
            BtnEditThemas.Visibility = Visibility.Visible;

            BtnAddPunten.Visibility = Visibility.Hidden;
            BtnRemovePunten.Visibility = Visibility.Hidden;
            BtnEditPunten.Visibility = Visibility.Hidden;

            BtnAddVerkiezingsSoorten.Visibility = Visibility.Hidden;
            BtnRemoveVerkiezingsSoorten.Visibility = Visibility.Hidden;
            BtnEditVerkiezingsSoorten.Visibility = Visibility.Hidden;

            BtnAddVerkiezingen.Visibility = Visibility.Hidden;
            BtnRemoveVerkiezingen.Visibility = Visibility.Hidden;
            BtnEditVerkiezingen.Visibility = Visibility.Hidden;
            BtnVerkiesbaar.Visibility = Visibility.Hidden;
        }

        private void MenuPunten_Click(object sender, RoutedEventArgs e)
        {
            MenuPartijen.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuPartijen.Foreground = Brushes.Black;
            MenuThemas.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuThemas.Foreground = Brushes.Black;
            MenuPunten.Background = Brushes.White;
            MenuPunten.Foreground = Brushes.Black;
            MenuVerkiezingsSoorten.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuVerkiezingsSoorten.Foreground = Brushes.Black;
            MenuVerkiezingen.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuVerkiezingen.Foreground = Brushes.Black;
           
            DgPartijen.Visibility = Visibility.Hidden;
            DgThemas.Visibility = Visibility.Hidden;
            DgPunten.Visibility = Visibility.Visible;
            DgVerkiezingsSoorten.Visibility = Visibility.Hidden;
            DgVerkiezingen.Visibility = Visibility.Hidden;

            BtnAddPartijen.Visibility = Visibility.Hidden;
            BtnRemovePartijen.Visibility = Visibility.Hidden;
            BtnEditPartijen.Visibility = Visibility.Hidden;

            BtnAddThemas.Visibility = Visibility.Hidden;
            BtnRemoveThemas.Visibility = Visibility.Hidden;
            BtnEditThemas.Visibility = Visibility.Hidden;

            BtnAddPunten.Visibility = Visibility.Visible;
            BtnRemovePunten.Visibility = Visibility.Visible;
            BtnEditPunten.Visibility = Visibility.Visible;

            BtnAddVerkiezingsSoorten.Visibility = Visibility.Hidden;
            BtnRemoveVerkiezingsSoorten.Visibility = Visibility.Hidden;
            BtnEditVerkiezingsSoorten.Visibility = Visibility.Hidden;

            BtnAddVerkiezingen.Visibility = Visibility.Hidden;
            BtnRemoveVerkiezingen.Visibility = Visibility.Hidden;
            BtnEditVerkiezingen.Visibility = Visibility.Hidden;
            BtnVerkiesbaar.Visibility = Visibility.Hidden;
        }

        private void MenuVerkiezingsSoorten_Click(object sender, RoutedEventArgs e)
        {
            MenuPartijen.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuPartijen.Foreground = Brushes.Black;
            MenuThemas.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuThemas.Foreground = Brushes.Black;
            MenuPunten.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuPunten.Foreground = Brushes.Black;
            MenuVerkiezingsSoorten.Background = Brushes.White;
            MenuVerkiezingsSoorten.Foreground = Brushes.Black;
            MenuVerkiezingen.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuVerkiezingen.Foreground = Brushes.Black;

            DgPartijen.Visibility = Visibility.Hidden;
            DgThemas.Visibility = Visibility.Hidden;
            DgPunten.Visibility = Visibility.Hidden;
            DgVerkiezingsSoorten.Visibility = Visibility.Visible;
            DgVerkiezingen.Visibility = Visibility.Hidden;

            BtnAddPartijen.Visibility = Visibility.Hidden;
            BtnRemovePartijen.Visibility = Visibility.Hidden;
            BtnEditPartijen.Visibility = Visibility.Hidden;

            BtnAddThemas.Visibility = Visibility.Hidden;
            BtnRemoveThemas.Visibility = Visibility.Hidden;
            BtnEditThemas.Visibility = Visibility.Hidden;

            BtnAddPunten.Visibility = Visibility.Hidden;
            BtnRemovePunten.Visibility = Visibility.Hidden;
            BtnEditPunten.Visibility = Visibility.Hidden;

            BtnAddVerkiezingsSoorten.Visibility = Visibility.Visible;
            BtnRemoveVerkiezingsSoorten.Visibility = Visibility.Visible;
            BtnEditVerkiezingsSoorten.Visibility = Visibility.Visible;

            BtnAddVerkiezingen.Visibility = Visibility.Hidden;
            BtnRemoveVerkiezingen.Visibility = Visibility.Hidden;
            BtnEditVerkiezingen.Visibility = Visibility.Hidden;
            BtnVerkiesbaar.Visibility = Visibility.Hidden;
        }

        private void MenuVerkiezingen_Click(object sender, RoutedEventArgs e)
        {
            MenuPartijen.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuThemas.Foreground = Brushes.Black;
            MenuThemas.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuThemas.Foreground = Brushes.Black;
            MenuPunten.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuPunten.Foreground = Brushes.Black;
            MenuVerkiezingsSoorten.Background = new SolidColorBrush(Color.FromRgb(221, 221, 221));
            MenuVerkiezingsSoorten.Foreground = Brushes.Black;
            MenuVerkiezingen.Background = Brushes.White;
            MenuVerkiezingen.Foreground = Brushes.Black;

            DgPartijen.Visibility = Visibility.Hidden;
            DgThemas.Visibility = Visibility.Hidden;
            DgPunten.Visibility = Visibility.Hidden;
            DgVerkiezingsSoorten.Visibility = Visibility.Hidden;
            DgVerkiezingen.Visibility = Visibility.Visible;

            BtnAddPartijen.Visibility = Visibility.Hidden;
            BtnRemovePartijen.Visibility = Visibility.Hidden;
            BtnEditPartijen.Visibility = Visibility.Hidden;

            BtnAddThemas.Visibility = Visibility.Hidden;
            BtnRemoveThemas.Visibility = Visibility.Hidden;
            BtnEditThemas.Visibility = Visibility.Hidden;

            BtnAddPunten.Visibility = Visibility.Hidden;
            BtnRemovePunten.Visibility = Visibility.Hidden;
            BtnEditPunten.Visibility = Visibility.Hidden;

            BtnAddVerkiezingsSoorten.Visibility = Visibility.Hidden;
            BtnRemoveVerkiezingsSoorten.Visibility = Visibility.Hidden;
            BtnEditVerkiezingsSoorten.Visibility = Visibility.Hidden;

            BtnAddVerkiezingen.Visibility = Visibility.Visible;
            BtnRemoveVerkiezingen.Visibility = Visibility.Visible;
            BtnEditVerkiezingen.Visibility = Visibility.Visible;
            BtnVerkiesbaar.Visibility = Visibility.Visible;
        }

        // input links
        // Partijen
        private void BtnAddPartijen_Click(object sender, RoutedEventArgs e)
        {
            Create Create = new Create();
            Create.Show();
        }

        private void BtnRemovePartijen_Click(object sender, RoutedEventArgs e)
        {
            Delete Delete = new Delete();
            Delete.Show();
        }

        private void BtnEditPartijen_Click(object sender, RoutedEventArgs e)
        {
            Edit Edit = new Edit();
            Edit.Show();
        }
        
        //Verkiesbaar button
        private void BtnVerkiesbaar_Click(object sender, RoutedEventArgs e)
        {
            Verkiesbaar Verkiesbaar = new Verkiesbaar();
            Verkiesbaar.Show();
        }
    }
}
